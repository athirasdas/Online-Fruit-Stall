import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
public class Payment extends HttpServlet {
 
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        Connection conn = null;
        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "fruitstall";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root";
        String password = "root";
        boolean login = false;
 String user = null;
Cookie[] cookies = req.getCookies();
if(cookies !=null){
for(Cookie cookie : cookies){
	if(cookie.getName().equals("email")) user = cookie.getValue();
}}
        Statement st;
        try {
            int num = 0;
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url + dbName, userName, password);
            System.out.println("Connected!"); 
            String jn = req.getParameter("fname");
            int reqs = Integer.parseInt(req.getParameter("reqnum"));
            
            String query = "SELECT * FROM fruits where fname='"+jn+"'";
            st = conn.createStatement();
            String query2="insert into Fruitlog values('"+user+"','"+jn+"','"+reqs+"')";
           st.execute(query2);
            ResultSet rs = st.executeQuery(query);
            
            while(rs.next()){
                num = rs.getInt("qty");
                
            
            }
            if(reqs>6){
                out.println("You can only order 5 kgs at a time!");
            }
           else if(reqs>num){
              out.println("No fruits available!");
            }
            else if(num == 0){
                out.println("Sorry, this fruit is not available!");
            }
            else {
                String query3 = "update fruits set qty = qty - '"+ reqs +"' where fname='"+jn+"' " ;
                out.println("<h>Successfully Ordered! We'll be at your doorsteps! see you soon :)</h>");
                st.executeUpdate(query3);
                
                
            }
            
        
            
            
        }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
            out.print(e);
            System.out.print("ff");
            e.printStackTrace();
        }
    }
}
    
//@Override
  //  public String getServletInfo() {
  //      return "Short description";
   // }
//}